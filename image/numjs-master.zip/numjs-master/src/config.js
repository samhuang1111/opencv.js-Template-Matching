'use strict';

module.exports = {
  printThreshold: 7,
  nFloatingValues: 5
};
