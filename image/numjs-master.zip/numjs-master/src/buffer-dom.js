'use strict';

module.exports.Buffer = function MockedBuffer () {};
